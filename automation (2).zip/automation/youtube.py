import tkinter as tk
from tkinter import ttk
import time
import random
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import threading

# 🔹 Load settings from JSON files
def load_settings():
    settings = {}
    files = ['settings.json', 'fingerprint_settings.json', 'cookies.json', 'proxy_settings.json', 'human_emulation_settings.json','bot_settings.json', 'traffic_settings.json']
    for file in files:
        try:
            with open(file, 'r') as f:
                settings.update(json.load(f))
        except Exception as e:
            print(f"⚠️ Could not load {file}: {e}")
    return settings

settings = load_settings()

# 🔹 Get number of threads from traffic.json
NUM_THREADS = int(settings.get("threads", 1))

# 🔹 Set ChromeDriver path
CHROMEDRIVER_PATH = settings.get("chromedriver_path", "chromedriver-win64\\chromedriver.exe")

def start_browser():
    """Initialize WebDriver with required options"""
    chrome_options = Options()
    chrome_options.add_argument("--mute-audio")
    chrome_options.add_argument("--start-maximized")

    if settings.get("proxy"):
        chrome_options.add_argument(f"--proxy-server={settings['proxy']}")

    if settings.get("user_agent"):
        chrome_options.add_argument(f"--user-agent={settings['user_agent']}")

    if settings.get("headless", False):
        chrome_options.add_argument("--headless")

    service = Service(CHROMEDRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    return driver

class YouTubeTrafficModuleUI:
    def __init__(self, parent):
        self.frame = tk.Frame(parent, bg="#2A2D32", padx=15, pady=15)
        self.frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.frame, text="🎥 YouTube Traffic Automation", font=("Arial", 16, "bold"), fg="white", bg="#2A2D32").pack(pady=10)

        # Video URL Entry
        self.add_labeled_entry("YouTube Video URL:", "video_url", 50)

        # Watch Duration Entry
        self.add_labeled_spinbox("Watch Duration (sec):", "watch_duration", 10, 600, 60)

        # Ad Skipping Checkbox
        self.skip_ads_var = tk.BooleanVar(value=settings.get("skip_ads", True))
        self.add_labeled_checkbox("Skip Ads", self.skip_ads_var)

        # Human Emulation Checkbox
        self.human_emulation_var = tk.BooleanVar(value=settings.get("human_emulation", True))
        self.add_labeled_checkbox("Enable Human Emulation", self.human_emulation_var)

        # Threads (Multiple Bots) - Disabled (loaded from traffic.json)
        tk.Label(self.frame, text="Number of Bots (Threads):", font=("Arial", 12), fg="white", bg="#2A2D32").pack()
        self.threads_label = tk.Label(self.frame, text=f"{NUM_THREADS} (Loaded from traffic.json)", font=("Arial", 12), fg="#7289DA", bg="#2A2D32")
        self.threads_label.pack(pady=5)

        # Start and Stop Buttons
        button_frame = tk.Frame(self.frame, bg="#2A2D32")
        button_frame.pack(pady=10)

        self.start_button = tk.Button(button_frame, text="▶ Start Bot", font=("Arial", 12, "bold"), bg="#43B581", fg="white", width=15, command=self.start_bot)
        self.start_button.pack(side=tk.LEFT, padx=5)

        self.stop_button = tk.Button(button_frame, text="⏹ Stop Bot", font=("Arial", 12, "bold"), bg="#F04747", fg="white", width=15, command=self.stop_bot, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)

        # Status Label
        self.status_label = tk.Label(self.frame, text="Status: Idle", font=("Arial", 12), fg="green", bg="#2A2D32")
        self.status_label.pack(pady=10)

        self.bot_running = False
        self.threads = []

    def add_labeled_entry(self, label_text, setting_key, width):
        frame = tk.Frame(self.frame, bg="#2A2D32")
        frame.pack(pady=5, fill=tk.X)

        tk.Label(frame, text=label_text, fg="white", bg="#2A2D32").pack(side=tk.LEFT, padx=5)
        entry = tk.Entry(frame, width=width, bg="#23272A", fg="white")
        entry.pack(side=tk.LEFT, padx=5)
        entry.insert(0, settings.get(setting_key, ""))

        setattr(self, f"{setting_key}_entry", entry)

    def add_labeled_spinbox(self, label_text, setting_key, from_, to, default):
        frame = tk.Frame(self.frame, bg="#2A2D32")
        frame.pack(pady=5, fill=tk.X)

        tk.Label(frame, text=label_text, fg="white", bg="#2A2D32").pack(side=tk.LEFT, padx=5)
        spinbox = tk.Spinbox(frame, from_=from_, to=to, width=5, bg="#23272A", fg="white")
        spinbox.pack(side=tk.LEFT, padx=5)
        spinbox.insert(0, settings.get(setting_key, str(default)))

        setattr(self, f"{setting_key}_entry", spinbox)

    def add_labeled_checkbox(self, text, var):
        tk.Checkbutton(self.frame, text=text, variable=var, font=("Arial", 10), fg="white", bg="#2A2D32", selectcolor="#23272A").pack(pady=2)

    def start_bot(self):
        url = self.video_url_entry.get()
        watch_time = int(self.watch_duration_entry.get())
        skip_ads = self.skip_ads_var.get()
        human_emulation = self.human_emulation_var.get()

        if not url:
            print("❌ Please enter a valid YouTube URL.")
            return

        self.status_label.config(text="Status: Running...", fg="blue")
        self.bot_running = True
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)

        # Start multiple bots (threads)
        self.threads = []
        for i in range(NUM_THREADS):
            thread = threading.Thread(target=self.run_bot, args=(url, watch_time, skip_ads, human_emulation, i+1))
            self.threads.append(thread)
            thread.start()

    def stop_bot(self):
        self.bot_running = False
        self.status_label.config(text="Status: Stopped", fg="red")
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)

    def run_bot(self, url, watch_time, skip_ads, human_emulation, thread_id):
        """Each bot runs in a separate thread"""
        try:
            print(f"▶️ Bot #{thread_id} watching YouTube Video: {url}")

            driver = start_browser()
            driver.get(url)
            time.sleep(5)

            if skip_ads:
                try:
                    ad_skip_button = driver.find_element(By.CLASS_NAME, "ytp-ad-skip-button")
                    ad_skip_button.click()
                    print(f"⏭️ Bot #{thread_id} Ad skipped!")
                except:
                    print(f"✅ Bot #{thread_id} No ads found to skip.")

            if human_emulation:
                for _ in range(random.randint(1, 5)):
                    driver.execute_script("window.scrollBy(0, 200)")
                    time.sleep(random.uniform(1, 5))

            time.sleep(watch_time)
            print(f"✅ Bot #{thread_id} finished watching video.")
            driver.quit()
        except Exception as e:
            print(f"❌ Error in Bot #{thread_id}: {e}")
        finally:
            if not self.bot_running:
                self.status_label.config(text="Status: Stopped", fg="red")

if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg="#2A2D32")
    root.title("YouTube Traffic Automation")
    app = YouTubeTrafficModuleUI(root)
    root.mainloop()

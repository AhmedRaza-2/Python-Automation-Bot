import tkinter as tk
from tkinter import filedialog, messagebox, ttk

class TrafficOptionsUI:
    def __init__(self, parent, settings):
        self.settings = settings  # Store settings
        self.frame = tk.Frame(parent, padx=10, pady=10, bg="#2A2D32")
        self.frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(self.frame, text="Traffic Options", font=("Arial", 16, "bold"), fg="#FFFFFF", bg="#2A2D32").pack(pady=5)
        
        # Threads Input
        self.add_labeled_spinbox("Threads:", "threads", 1, 100, 5)
        
        # Total Visit Numbers
        self.add_labeled_spinbox("Total Visit Numbers:", "visits", 1, 1000, 10)
        
        # Choose Traffic Option (Check Buttons)
        tk.Label(self.frame, text="Choose Traffic Option:", font=("Arial", 12, "bold"), fg="#FFFFFF", bg="#2A2D32").pack(pady=5)
        self.dynamic_fields = {}  # Store dynamic input fields
        self.traffic_options = {
            "Direct Traffic": tk.BooleanVar(value=settings.get("direct_traffic", True)),
            "Google Search Traffic": tk.BooleanVar(value=settings.get("google_traffic", False)),
            "Bing Search Traffic": tk.BooleanVar(value=settings.get("bing_traffic", False)),
            "DuckDuckGo Search Traffic": tk.BooleanVar(value=settings.get("duckduckgo_traffic", False)),
            "Yahoo Search Traffic": tk.BooleanVar(value=settings.get("yahoo_traffic", False)),
            "Pinterest Traffic": tk.BooleanVar(value=settings.get("pinterest_traffic", False)),
            "Quora Traffic": tk.BooleanVar(value=settings.get("quora_traffic", False)),
            "Twitter Traffic": tk.BooleanVar(value=settings.get("twitter_traffic", False)),
            "Facebook Traffic": tk.BooleanVar(value=settings.get("facebook_traffic", False)),
            "Medium Traffic": tk.BooleanVar(value=settings.get("medium_traffic", False)),
        }
        
        for option, var in self.traffic_options.items():
            cb = tk.Checkbutton(self.frame, text=option, variable=var, command=lambda opt=option: self.toggle_field(opt), 
                                fg="#FFFFFF", bg="#2A2D32", selectcolor="#2E3136", activebackground="#2A2D32")
            cb.pack(anchor="w")
            
            # Create an input field but keep it hidden initially
            self.dynamic_fields[option] = self.add_labeled_entry(f"Enter {option} Query:", option.lower().replace(" ", "_"), hidden=True)
        
        # Enter Targeted Domain
        self.add_labeled_entry("Enter Targeted Domain:", "domain", default="google.com")
        
        # Post URL List Selection
        tk.Label(self.frame, text="Post URL List:", font=("Arial", 12, "bold"), fg="#FFFFFF", bg="#2A2D32").pack()
        self.url_list_entry = tk.Entry(self.frame, width=40, bg="#1E1F22", fg="#FFFFFF", insertbackground="white")
        self.url_list_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(self.frame, text="📂", command=self.browse_file, bg="#7289DA", fg="#FFFFFF").pack(side=tk.LEFT)
        self.url_list_entry.insert(0, settings.get("post_url_list", ""))
        
        # Min & Max Pages
        self.add_labeled_spinbox("Minimum Pages to Visit:", "min_pages", 1, 100, 1)
        self.add_labeled_spinbox("Maximum Pages to Visit:", "max_pages", 1, 100, 5)
        
        # Start Button
        tk.Button(self.frame, text="Start Traffic", font=("Arial", 12, "bold"), command=self.start_traffic, 
                  bg="#43B581", fg="#FFFFFF").pack(pady=10)

    def add_labeled_entry(self, label, setting_key, default="", hidden=False):
        frame = tk.Frame(self.frame, bg="#2A2D32")
        tk.Label(frame, text=label, fg="#FFFFFF", bg="#2A2D32").pack(side=tk.LEFT, padx=5)
        entry = tk.Entry(frame, width=30, bg="#1E1F22", fg="#FFFFFF", insertbackground="white")
        entry.insert(0, self.settings.get(setting_key, default))
        entry.pack(side=tk.LEFT, padx=5)
        frame.pack(pady=2, fill=tk.X)
        if hidden:
            frame.pack_forget()  # Hide initially
        setattr(self, f"{setting_key}_entry", entry)
        return {"frame": frame, "entry": entry}
    
    def add_labeled_spinbox(self, label, setting_key, from_, to, default):
        frame = tk.Frame(self.frame, bg="#2A2D32")
        tk.Label(frame, text=label, fg="#FFFFFF", bg="#2A2D32").pack(side=tk.LEFT, padx=5)
        spinbox = tk.Spinbox(frame, from_=from_, to=to, width=5, bg="#1E1F22", fg="#FFFFFF", insertbackground="white")
        spinbox.pack(side=tk.LEFT, padx=5)
        spinbox.insert(0, self.settings.get(setting_key, str(default)))
        frame.pack(pady=2, fill=tk.X)
        setattr(self, f"{setting_key}_entry", spinbox)
        return spinbox
    
    def toggle_field(self, option):
        if self.traffic_options[option].get():
            self.dynamic_fields[option]["frame"].pack(pady=2, fill=tk.X)
        else:
            self.dynamic_fields[option]["frame"].pack_forget()
    
    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file_path:
            self.url_list_entry.delete(0, tk.END)
            self.url_list_entry.insert(0, file_path)
            self.settings["post_url_list"] = file_path
    
    def start_traffic(self):
        self.settings.update({
            "threads": self.threads_entry.get(),
            "visits": self.visits_entry.get(),
            "domain": self.domain_entry.get(),
            "post_url_list": self.url_list_entry.get(),
            "min_pages": self.min_pages_entry.get(),
            "max_pages": self.max_pages_entry.get(),
        })
        for option, var in self.traffic_options.items():
            key = option.lower().replace(" ", "_")
            self.settings[key] = var.get()
            if var.get():
                self.settings[key + "_query"] = self.dynamic_fields[option]["entry"].get()
        print("Traffic Started with settings:", self.settings)
        messagebox.showinfo("Traffic Started", "Traffic simulation has started with the selected settings.")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Traffic Bot")
    root.configure(bg="#2A2D32")
    settings = {}
    app = TrafficOptionsUI(root, settings)
    root.mainloop()

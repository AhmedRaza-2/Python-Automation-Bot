import tkinter as tk
from tkinter import ttk
from human_emulation import HumanEmulationUI
from traffic_bot import TrafficOptionsUI
from fingerprint import FingerprintSetupUI
from proxy_manager import ProxySetupUI
from ad_clicker import AdClickerUI
from cookies import CookiesSetupUI
from youtube import YouTubeTrafficModuleUI
from website import WebsiteTrafficModuleUI

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("IT INNOSYS - Traffic Generator")
        self.root.geometry("900x500")
        self.root.configure(bg="#2E2E2E")
        
        # Left-side navigation panel
        self.nav_frame = tk.Frame(self.root, bg="#333", width=220)
        self.nav_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        
        # Main content area (with padding for better spacing)
        self.content_frame = tk.Frame(self.root, bg="#444")
        self.content_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Buttons for navigation with styling
        buttons = [
            ("YouTube Bot", self.load_youtube),
            ("Website Bot", self.load_website),
            ("Human Emulation", self.load_human_emulation),
            ("Ad Clicker", self.load_AdClickerUI),
            ("Cookies Setup", self.load_cookies),
            ("Fingerprint Setup", self.load_fingerprint),
            ("Proxy Manager", self.load_proxy),
            ("Traffic Options", self.load_traffic)
        ]
        
        for text, command in buttons:
            btn = tk.Button(self.nav_frame, text=text, command=command, fg="white", bg="#444", relief=tk.FLAT, height=2)
            btn.pack(fill=tk.X, padx=5, pady=2)
        
        # Default View
        self.load_youtube()
    
    def clear_content(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
    
    def load_youtube(self):
        self.clear_content()
        YouTubeTrafficModuleUI(self.content_frame) 
    
    def load_website(self):
        self.clear_content()
        WebsiteTrafficModuleUI(self.content_frame) 
    
    def load_human_emulation(self):
        self.clear_content()
        HumanEmulationUI(self.content_frame)

    def load_AdClickerUI(self):
        self.clear_content()
        AdClickerUI(self.content_frame)

    def load_cookies(self):
        self.clear_content()
        CookiesSetupUI(self.content_frame)

    def load_fingerprint(self):
        self.clear_content()
        FingerprintSetupUI(self.content_frame)

    def load_proxy(self):
        self.clear_content()
        ProxySetupUI(self.content_frame)
    
    def load_traffic(self):
        self.clear_content()
        self.settings = {}
        TrafficOptionsUI(self.content_frame, self.settings)
    
if __name__ == "__main__":
    root = tk.Tk()
    root.configure(bg="#2A2D32")
    root.title("IT INNOSYS - Traffic Generator")
    app = MainApp(root)
    root.mainloop()

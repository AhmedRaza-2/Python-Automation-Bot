import json
import tkinter as tk
from tkinter import ttk, messagebox
import os

SETTINGS_FILE = "human_emulation_settings.json"  # JSON file to store settings

class HumanEmulationUI:
    def __init__(self, parent):
        self.settings = self.load_settings()  # Load settings from JSON
        self.frame = tk.Frame(parent, bg="#2A2D32")  # Dark background
        self.frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.frame, text="Human Emulation Settings", font=("Arial", 16), bg="#2A2D32", fg="white").pack(pady=10)

        # Minimum Time for Human Emulation (Spinbox)
        tk.Label(self.frame, text="Minimum Time for Human Emulation (sec):", bg="#2A2D32", fg="white").pack()
        self.min_time_spinbox = tk.Spinbox(self.frame, from_=1, to=300, width=10, bg="#3A3D42", fg="white", insertbackground="white")
        self.min_time_spinbox.pack()
        self.min_time_spinbox.insert(0, self.settings.get("min_time", "30"))  # Load from settings

        # Maximum Time for Human Emulation (Spinbox)
        tk.Label(self.frame, text="Maximum Time for Human Emulation (sec):", bg="#2A2D32", fg="white").pack()
        self.max_time_spinbox = tk.Spinbox(self.frame, from_=1, to=600, width=10, bg="#3A3D42", fg="white", insertbackground="white")
        self.max_time_spinbox.pack()
        self.max_time_spinbox.insert(0, self.settings.get("max_time", "80"))  # Load from settings

        # Start Emulation Button
        self.start_button = tk.Button(self.frame, text="Start Emulation", command=self.start_emulation, bg="#007BFF", fg="white", activebackground="#0056b3", activeforeground="white")
        self.start_button.pack(pady=10)

        # Save Settings Button
        self.save_button = tk.Button(self.frame, text="Save Settings", command=self.save_settings, bg="#28A745", fg="white", activebackground="#1e7e34", activeforeground="white")
        self.save_button.pack(pady=5)

    def start_emulation(self):
        """Save settings and start human emulation"""
        min_time = self.min_time_spinbox.get()
        max_time = self.max_time_spinbox.get()

        # Validate input
        try:
            min_time = int(min_time)
            max_time = int(max_time)

            if min_time <= 0 or max_time <= 0:
                raise ValueError("Time values must be positive integers.")
            if min_time > max_time:
                raise ValueError("Minimum time cannot be greater than maximum time.")

            # Update settings
            self.settings["min_time"] = min_time
            self.settings["max_time"] = max_time

            # Save settings
            self.save_settings()

            # Print settings (for testing or logging purposes)
            print(f"Human Emulation Started: Min Time-{self.settings['min_time']} sec, Max Time-{self.settings['max_time']} sec")

            # Show confirmation
            messagebox.showinfo("Emulation Started", f"Human Emulation started with Min Time: {min_time} sec, Max Time: {max_time} sec.")

        except ValueError as e:
            messagebox.showerror("Invalid Input", f"Error: {str(e)}")

    def save_settings(self):
        """Save settings to a JSON file"""
        self.settings["min_time"] = self.min_time_spinbox.get()
        self.settings["max_time"] = self.max_time_spinbox.get()

        with open(SETTINGS_FILE, "w") as f:
            json.dump(self.settings, f, indent=4)

        messagebox.showinfo("Settings Saved", "Your settings have been saved successfully!")

    @staticmethod
    def load_settings():
        """Load settings from JSON file"""
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, "r") as f:
                return json.load(f)
        return {}  # Return empty dict if no settings file exists

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Human Emulation Settings")
    root.configure(bg="#2A2D32")  # Dark background
    app = HumanEmulationUI(root)  # Initialize the HumanEmulationUI
    root.mainloop()

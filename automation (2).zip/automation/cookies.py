import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json

COOKIES_FILE = "cookies.json"

def load_cookies_settings():
    """Load cookies settings from cookies.json"""
    try:
        with open(COOKIES_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}  # Return empty settings if file not found or corrupted

def save_cookies_settings(settings):
    """Save cookies settings to cookies.json"""
    with open(COOKIES_FILE, 'w') as f:
        json.dump(settings, f, indent=4)

class CookiesSetupUI:
    def __init__(self, parent):
        self.settings = load_cookies_settings()
        self.frame = tk.Frame(parent, padx=20, pady=20, bg="#2A2D32")  # Dark background
        self.frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.frame, text="Cookies Setup", font=("Arial", 16, "bold"), bg="#2A2D32", fg="white").grid(row=0, column=0, columnspan=3, pady=10, sticky="w")

        # Use Cookies Checkbox
        self.use_cookies_var = tk.BooleanVar(value=self.settings.get("use_cookies", True))
        self.use_cookies_checkbox = tk.Checkbutton(self.frame, text="Use Cookies", variable=self.use_cookies_var, bg="#2A2D32", fg="white", selectcolor="#3A3D42")
        self.use_cookies_checkbox.grid(row=1, column=0, columnspan=2, sticky="w", pady=5)

        # Select Cookies Option (Dropdown)
        tk.Label(self.frame, text="Select Cookies Option:", bg="#2A2D32", fg="white").grid(row=2, column=0, sticky="w", pady=5)
        self.cookies_option = ttk.Combobox(self.frame, values=["Create Cookies", "Use Existing Cookies"], state="readonly", width=30)
        self.cookies_option.grid(row=2, column=1, columnspan=2, pady=5, sticky="w")
        self.cookies_option.set(self.settings.get("cookies_option", "Create Cookies"))
        self.cookies_option.bind("<<ComboboxSelected>>", self.toggle_existing_cookies_options)

        # Google Search Keywords
        tk.Label(self.frame, text="Google Search Keywords:", bg="#2A2D32", fg="white").grid(row=3, column=0, sticky="w", pady=5)
        self.keyword_entry = tk.Entry(self.frame, width=40, bg="#3A3D42", fg="white", insertbackground="white")
        self.keyword_entry.grid(row=3, column=1, columnspan=2, pady=5, sticky="w")
        self.keyword_entry.insert(0, self.settings.get("search_keywords", ""))

        # Dynamic Fields
        self.cookies_format_label = tk.Label(self.frame, text="Select Cookies Format:", bg="#2A2D32", fg="white")
        self.cookies_format_option = ttk.Combobox(self.frame, values=["BAS Cookies", "Netscape Format"], state="readonly", width=30)

        self.cookies_folder_label = tk.Label(self.frame, text="Choose Cookies Folder:", bg="#2A2D32", fg="white")
        self.cookies_folder_entry = tk.Entry(self.frame, width=35, bg="#3A3D42", fg="white", insertbackground="white")
        self.browse_folder_btn = tk.Button(self.frame, text="📂", command=self.browse_location, bg="#007BFF", fg="white", activebackground="#0056b3")

        self.save_location_label = tk.Label(self.frame, text="Save Cookies Location:", bg="#2A2D32", fg="white")
        self.save_location_entry = tk.Entry(self.frame, width=35, bg="#3A3D42", fg="white", insertbackground="white")
        self.browse_save_btn = tk.Button(self.frame, text="📂", command=self.browse_save_location, bg="#007BFF", fg="white", activebackground="#0056b3")

        # Min & Max Sites
        tk.Label(self.frame, text="Min Sites Before Saving Cookies:", bg="#2A2D32", fg="white").grid(row=4, column=0, sticky="w", pady=5)
        self.min_sites_spinbox = tk.Spinbox(self.frame, from_=1, to=100, width=10, bg="#3A3D42", fg="white", insertbackground="white")
        self.min_sites_spinbox.grid(row=4, column=1, pady=5, sticky="w")
        self.min_sites_spinbox.insert(0, self.settings.get("min_sites", "1"))

        tk.Label(self.frame, text="Max Sites Before Saving Cookies:", bg="#2A2D32", fg="white").grid(row=5, column=0, sticky="w", pady=5)
        self.max_sites_spinbox = tk.Spinbox(self.frame, from_=1, to=500, width=10, bg="#3A3D42", fg="white", insertbackground="white")
        self.max_sites_spinbox.grid(row=5, column=1, pady=5, sticky="w")
        self.max_sites_spinbox.insert(0, self.settings.get("max_sites", "1"))

        # Save Cookies Button
        self.save_button = tk.Button(self.frame, text="Save Settings", command=self.save_cookies, bg="#28A745", fg="white", activebackground="#1e7e34", padx=10, pady=5)
        self.save_button.grid(row=8, column=0, columnspan=3, pady=10)

        self.toggle_existing_cookies_options()  # Hide extra options initially

    def toggle_existing_cookies_options(self, event=None):
        """Show or hide extra options based on the selected cookies option"""
        if self.cookies_option.get() == "Use Existing Cookies":
            self.cookies_format_label.grid(row=6, column=0, sticky="w", pady=5)
            self.cookies_format_option.grid(row=6, column=1, columnspan=2, pady=5, sticky="w")
            self.cookies_folder_label.grid(row=7, column=0, sticky="w", pady=5)
            self.cookies_folder_entry.grid(row=7, column=1, pady=5, sticky="w")
            self.browse_folder_btn.grid(row=7, column=2, padx=5)
            self.save_location_label.grid_remove()
            self.save_location_entry.grid_remove()
            self.browse_save_btn.grid_remove()
        else:
            self.cookies_format_label.grid_remove()
            self.cookies_format_option.grid_remove()
            self.cookies_folder_label.grid_remove()
            self.cookies_folder_entry.grid_remove()
            self.browse_folder_btn.grid_remove()
            self.save_location_label.grid(row=6, column=0, sticky="w", pady=5)
            self.save_location_entry.grid(row=6, column=1, pady=5, sticky="w")
            self.browse_save_btn.grid(row=6, column=2, padx=5)

    def browse_location(self):
        file_path = filedialog.askdirectory(title="Select Existing Cookies Folder")
        if file_path:
            self.cookies_folder_entry.delete(0, tk.END)
            self.cookies_folder_entry.insert(0, file_path)

    def browse_save_location(self):
        file_path = filedialog.askdirectory(title="Select Save Location for Cookies")
        if file_path:
            self.save_location_entry.delete(0, tk.END)
            self.save_location_entry.insert(0, file_path)

    def save_cookies(self):
        self.settings["use_cookies"] = self.use_cookies_var.get()
        self.settings["cookies_option"] = self.cookies_option.get()
        self.settings["search_keywords"] = self.keyword_entry.get()
        self.settings["min_sites"] = self.min_sites_spinbox.get()
        self.settings["max_sites"] = self.max_sites_spinbox.get()
        save_cookies_settings(self.settings)
        messagebox.showinfo("Settings Saved", "Cookies setup settings have been saved successfully!")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Cookies Setup")
    root.configure(bg="#2A2D32")
    app = CookiesSetupUI(root)
    root.mainloop()

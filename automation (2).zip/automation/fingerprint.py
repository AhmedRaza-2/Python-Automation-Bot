import tkinter as tk
from tkinter import ttk, messagebox
import json

class FingerprintSetupUI:
    def __init__(self, parent, settings_file="fingerprint_settings.json"):
        self.settings_file = settings_file
        self.settings = self.load_settings()

        # Set black background for the main frame
        self.frame = tk.Frame(parent, padx=15, pady=15, bg="#2A2D32")
        self.frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.frame, text="Fingerprint Setup", font=("Arial", 16, "bold"), fg="white", bg="#2A2D32").grid(row=0, column=0, columnspan=2, pady=10)

        # Fingerprint Provider Selection
        tk.Label(self.frame, text="Choose Fingerprint Provider:", fg="white", bg="#2A2D32").grid(row=1, column=0, sticky='w', padx=5, pady=3)
        self.fingerprint_provider = ttk.Combobox(self.frame, values=["Bablosoft API", "ProxyGeo API"], state="readonly", width=25)
        self.fingerprint_provider.grid(row=1, column=1, sticky='w', padx=5, pady=3)
        self.fingerprint_provider.set(self.settings.get("fingerprint_provider", "Bablosoft API"))
        self.fingerprint_provider.bind("<<ComboboxSelected>>", self.toggle_api_input)

        # API Key Entry (Bablosoft)
        tk.Label(self.frame, text="Bablosoft API Key:", fg="white", bg="#2A2D32").grid(row=2, column=0, sticky='w', padx=5, pady=3)
        self.bablosoft_api_entry = tk.Entry(self.frame, width=30, show="*")
        self.bablosoft_api_entry.grid(row=2, column=1, sticky='w', padx=5, pady=3)
        self.bablosoft_api_entry.insert(0, self.settings.get("bablosoft_api_key", ""))

        # API Key Entry (ProxyGeo)
        tk.Label(self.frame, text="ProxyGeo API Key:", fg="white", bg="#2A2D32").grid(row=3, column=0, sticky='w', padx=5, pady=3)
        self.proxygeo_api_entry = tk.Entry(self.frame, width=30, show="*")
        self.proxygeo_api_entry.grid(row=3, column=1, sticky='w', padx=5, pady=3)
        self.proxygeo_api_entry.insert(0, self.settings.get("proxygeo_api_key", ""))

        # Fingerprint Age Selection
        tk.Label(self.frame, text="Choose Fingerprints Age:", fg="white", bg="#2A2D32").grid(row=4, column=0, sticky='w', padx=5, pady=3)
        self.fingerprint_age = ttk.Combobox(self.frame, values=["ALL Time", "Last 30 Days", "Last 7 Days"], state="readonly", width=25)
        self.fingerprint_age.grid(row=4, column=1, sticky='w', padx=5, pady=3)
        self.fingerprint_age.set(self.settings.get("fingerprint_age", "ALL Time"))

        # Custom Fingerprint Devices Checkbox
        self.custom_devices_var = tk.BooleanVar(value=self.settings.get("custom_devices", False))
        self.custom_devices_checkbox = tk.Checkbutton(self.frame, text="Select Custom Fingerprint Devices", variable=self.custom_devices_var, fg="white", bg="black", selectcolor="black")
        self.custom_devices_checkbox.grid(row=5, column=0, columnspan=2, sticky='w', padx=5, pady=3)

        # Device Selection (Two Columns)
        tk.Label(self.frame, text="Choose Devices:", fg="white", bg="#2A2D32").grid(row=6, column=0, sticky='w', padx=5, pady=(10, 0))

        self.devices = ["Mobile", "Windows", "Mac", "Android", "Linux", "iPad", "iPhone", "Edge", "Chrome", "Safari", "Firefox", "IE"]
        self.device_vars = {}

        device_frame = tk.Frame(self.frame, bg="#2A2D32")
        device_frame.grid(row=7, column=0, columnspan=2, sticky="w", padx=5, pady=3)

        for i, device in enumerate(self.devices):
            self.device_vars[device] = tk.BooleanVar(value=self.settings.get("devices", {}).get(device, False))
            tk.Checkbutton(device_frame, text=device, variable=self.device_vars[device], fg="white", bg="#2A2D32", selectcolor="#2A2D32").grid(row=i // 2, column=i % 2, sticky='w', padx=5, pady=2)

        # Save Button
        tk.Button(self.frame, text="Save Settings", command=self.save_settings, font=("Arial", 12, "bold"), bg="white", fg="#2A2D32").grid(row=8, column=0, columnspan=2, pady=15)

        self.toggle_api_input()  # Adjust UI based on selected fingerprint provider

    def toggle_api_input(self, event=None):
        """ Show the relevant API key field based on provider selection """
        provider = self.fingerprint_provider.get()
        if provider == "Bablosoft API":
            self.bablosoft_api_entry.config(state="normal")
            self.proxygeo_api_entry.config(state="disabled")
        else:
            self.bablosoft_api_entry.config(state="disabled")
            self.proxygeo_api_entry.config(state="normal")

    def save_settings(self):
        """ Save settings to JSON file """
        bablosoft_api_key = self.bablosoft_api_entry.get().strip()
        proxygeo_api_key = self.proxygeo_api_entry.get().strip()

        if self.fingerprint_provider.get() == "Bablosoft API" and not bablosoft_api_key:
            messagebox.showerror("Error", "Bablosoft API Key is required.")
            return
        if self.fingerprint_provider.get() == "ProxyGeo API" and not proxygeo_api_key:
            messagebox.showerror("Error", "ProxyGeo API Key is required.")
            return

        self.settings["fingerprint_provider"] = self.fingerprint_provider.get()
        self.settings["bablosoft_api_key"] = bablosoft_api_key
        self.settings["proxygeo_api_key"] = proxygeo_api_key
        self.settings["fingerprint_age"] = self.fingerprint_age.get()
        self.settings["custom_devices"] = self.custom_devices_var.get()
        self.settings["devices"] = {device: var.get() for device, var in self.device_vars.items()}

        self.save_to_file()
        messagebox.showinfo("Settings Saved", "Fingerprint setup has been saved successfully!")

    def save_to_file(self):
        """ Save settings to JSON file """
        with open(self.settings_file, "w") as f:
            json.dump(self.settings, f, indent=4)

    def load_settings(self):
        """ Load settings from JSON file """
        try:
            with open(self.settings_file, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Fingerprint Setup")
    root.configure(bg="#2A2D32")
    app = FingerprintSetupUI(root)
    root.mainloop()

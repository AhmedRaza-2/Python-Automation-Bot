import json
import random
import tkinter as tk
from tkinter import ttk, messagebox
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import os

SETTINGS_FILE = "settings.json"

class AdClickerUI:
    def __init__(self, parent):
        self.settings = self.load_settings()  # Load settings on startup
        self.frame = tk.Frame(parent, bg="#2A2D32")
        self.frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.frame, text="Ad Clicker Settings", font=("Arial", 16), fg="white", bg="#2A2D32").pack(pady=10)

        # Website URL Input Box
        tk.Label(self.frame, text="Enter Website URL:", fg="white", bg="#2A2D32").pack()
        self.website_entry = tk.Entry(self.frame, width=40, bg="#2A2D32", fg="white", insertbackground="white")
        self.website_entry.pack()
        self.website_entry.insert(0, self.settings.get("website_url", ""))

        # XPath Input Box
        tk.Label(self.frame, text="Enter XPath for Ad:", fg="white", bg="#2A2D32").pack()
        self.xpath_entry = tk.Entry(self.frame, width=40, bg="#2A2D32", fg="white", insertbackground="white")
        self.xpath_entry.pack()
        self.xpath_entry.insert(0, self.settings.get("xpath", ""))

        # Click on Ads Checkbox
        self.click_ads_var = tk.BooleanVar(value=self.settings.get("click_ads", True))
        self.click_ads_checkbox = tk.Checkbutton(self.frame, text="Click on Ads", variable=self.click_ads_var, fg="white", bg="#2A2D32", selectcolor="#2A2D32")
        self.click_ads_checkbox.pack()

        # Select Ad Click Option (Dropdown)
        tk.Label(self.frame, text="Select Ad Click Option:", fg="white", bg="#2A2D32").pack()
        self.ad_click_option = ttk.Combobox(self.frame, values=["Click on Custom Class", "Click on Random Ads"], state="readonly")
        self.ad_click_option.pack()
        self.ad_click_option.set(self.settings.get("ad_click_option", "Click on Custom Class"))
        self.ad_click_option.bind("<<ComboboxSelected>>", self.toggle_custom_class)

        # Enter Custom Class
        tk.Label(self.frame, text="Enter Custom Class:", fg="white", bg="#2A2D32").pack()
        self.ad_class_entry = tk.Entry(self.frame, bg="#2A2D32", fg="white", insertbackground="white")
        self.ad_class_entry.pack()
        self.ad_class_entry.insert(0, self.settings.get("custom_class", ""))
        self.toggle_custom_class()  # Apply initial state

        # Select Percentage of Ads Click
        tk.Label(self.frame, text="Select Percentage of Ads Click:", fg="white", bg="#2A2D32").pack()
        self.percentage_spinbox = tk.Spinbox(self.frame, from_=1, to=100, width=10, bg="#2A2D32", fg="white", insertbackground="white")
        self.percentage_spinbox.pack()
        self.percentage_spinbox.insert(0, self.settings.get("click_percentage", "100"))

        # Minimum & Maximum Time to Wait on Advertiser's Site
        tk.Label(self.frame, text="Min Wait Time (sec):", fg="white", bg="#2A2D32").pack()
        self.min_wait_spinbox = tk.Spinbox(self.frame, from_=1, to=300, width=10, bg="#2A2D32", fg="white", insertbackground="white")
        self.min_wait_spinbox.pack()
        self.min_wait_spinbox.insert(0, self.settings.get("min_wait", "20"))

        tk.Label(self.frame, text="Max Wait Time (sec):", fg="white", bg="#2A2D32").pack()
        self.max_wait_spinbox = tk.Spinbox(self.frame, from_=1, to=600, width=10, bg="#2A2D32", fg="white", insertbackground="white")
        self.max_wait_spinbox.pack()
        self.max_wait_spinbox.insert(0, self.settings.get("max_wait", "40"))

        # Click Random Links Checkbox
        self.click_random_links_var = tk.BooleanVar(value=self.settings.get("click_random_links", True))
        self.click_random_links_checkbox = tk.Checkbutton(self.frame, text="Click Random Links on Advertiser Site", variable=self.click_random_links_var, fg="white", bg="#2A2D32", selectcolor="#2A2D32")
        self.click_random_links_checkbox.pack()

        # Min & Max Pages to Visit
        tk.Label(self.frame, text="Min Pages to Visit:", fg="white", bg="#2A2D32").pack()
        self.min_pages_spinbox = tk.Spinbox(self.frame, from_=1, to=10, width=10, bg="#2A2D32", fg="white", insertbackground="white")
        self.min_pages_spinbox.pack()
        self.min_pages_spinbox.insert(0, self.settings.get("min_pages", "1"))

        tk.Label(self.frame, text="Max Pages to Visit:", fg="white", bg="#2A2D32").pack()
        self.max_pages_spinbox = tk.Spinbox(self.frame, from_=1, to=50, width=10, bg="#2A2D32", fg="white", insertbackground="white")
        self.max_pages_spinbox.pack()
        self.max_pages_spinbox.insert(0, self.settings.get("max_pages", "2"))

        # Start Button
        tk.Button(self.frame, text="Start Clicking", command=self.start_clicking, bg="#007BFF", fg="white").pack(pady=10)

        # Save Settings Button
        tk.Button(self.frame, text="Save Settings", command=self.save_settings, bg="#28A745", fg="white").pack(pady=5)

    def toggle_custom_class(self, event=None):
        """Enable or disable the 'Custom Class' field based on selection"""
        if self.ad_click_option.get() == "Click on Random Ads":
            self.ad_class_entry.config(state=tk.DISABLED)
        else:
            self.ad_class_entry.config(state=tk.NORMAL)

    def start_clicking(self):
        """Start ad clicking process"""
        # Save settings before running
        self.save_settings()

        # Retrieve values
        url = self.settings["website_url"]
        xpath = self.settings["xpath"]

        if not url or not xpath:
            messagebox.showerror("Error", "Please enter a valid website URL and XPath!")
            return

        driver = webdriver.Chrome()
        try:
            driver.get(url)
            time.sleep(2)
            ad_element = driver.find_element(By.XPATH, xpath)
            ad_element.click()
            print("Ad clicked successfully!")

            wait_time = random.randint(int(self.settings["min_wait"]), int(self.settings["max_wait"]))
            print(f"Waiting for {wait_time} seconds on the advertiser's site...")
            time.sleep(wait_time)

            if self.settings["click_random_links"]:
                print("Clicking random links on the site...")
                # Implement random link clicking logic here

        except Exception as e:
            print(f"Error: {e}")
        finally:
            driver.quit()

        messagebox.showinfo("Ad Clicker", "Ad Click completed successfully!")

    def save_settings(self):
        """Save settings to a JSON file"""
        self.settings = {
            "website_url": self.website_entry.get(),
            "xpath": self.xpath_entry.get(),
            "click_ads": self.click_ads_var.get(),
            "ad_click_option": self.ad_click_option.get(),
            "custom_class": self.ad_class_entry.get() if self.ad_click_option.get() == "Click on Custom Class" else "",
            "click_percentage": self.percentage_spinbox.get(),
            "min_wait": self.min_wait_spinbox.get(),
            "max_wait": self.max_wait_spinbox.get(),
            "click_random_links": self.click_random_links_var.get(),
            "min_pages": self.min_pages_spinbox.get(),
            "max_pages": self.max_pages_spinbox.get()
        }

        with open(SETTINGS_FILE, "w") as f:
            json.dump(self.settings, f, indent=4)
        
        messagebox.showinfo("Settings Saved", "Your settings have been saved successfully!")

    @staticmethod
    def load_settings():
        """Load settings from JSON file"""
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, "r") as f:
                return json.load(f)
        return {}  # Return empty dict if no settings file exists

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Ad Clicker Setup")
    root.configure(bg="#2A2D32")
    app = AdClickerUI(root)
    root.mainloop()

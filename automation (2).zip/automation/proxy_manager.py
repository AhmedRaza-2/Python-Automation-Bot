import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json

class ProxySetupUI:
    def __init__(self, parent, settings_file="proxy_settings.json"):
        self.settings_file = settings_file
        self.settings = self.load_settings()  # Load stored settings

        self.frame = tk.Frame(parent, padx=20, pady=20, bg="#2A2D32")
        self.frame.pack(fill=tk.BOTH, expand=True)

        tk.Label(self.frame, text="Proxy Setup", font=("Arial", 16, "bold"), fg="#FFFFFF", bg="#2A2D32").grid(row=0, column=0, columnspan=3, pady=10, sticky="w")

        # Choose Proxy File
        tk.Label(self.frame, text="Choose Proxy File:", fg="#FFFFFF", bg="#2A2D32").grid(row=1, column=0, sticky="w", pady=5)
        self.proxy_file_entry = tk.Entry(self.frame, width=35, bg="#3A3D42", fg="#FFFFFF", insertbackground="white")
        self.proxy_file_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        tk.Button(self.frame, text="📂", command=self.browse_file, bg="#4CAF50", fg="white").grid(row=1, column=2, padx=5)

        if "proxy_file" in self.settings:
            self.proxy_file_entry.insert(0, self.settings["proxy_file"])

        # Proxy Quality Check
        tk.Label(self.frame, text="Check Proxy Quality:", fg="#FFFFFF", bg="#2A2D32").grid(row=2, column=0, sticky="w", pady=5)
        self.proxy_quality = ttk.Combobox(self.frame, values=["Check in Browser", "Do Not Check"], state="readonly", width=30)
        self.proxy_quality.grid(row=2, column=1, columnspan=2, pady=5, sticky="w")
        self.proxy_quality.set(self.settings.get("proxy_quality", "Check in Browser"))

        # Proxy Checking Option
        tk.Label(self.frame, text="Proxy Checking Option:", fg="#FFFFFF", bg="#2A2D32").grid(row=3, column=0, sticky="w", pady=5)
        self.proxy_checking = ttk.Combobox(self.frame, values=["Check Proxy only on Ad Click", "Check Proxy on Every Visit"], state="readonly", width=30)
        self.proxy_checking.grid(row=3, column=1, columnspan=2, pady=5, sticky="w")
        self.proxy_checking.set(self.settings.get("proxy_checking", "Check Proxy only on Ad Click"))

        # Fraud Score
        tk.Label(self.frame, text="Max Fraud Score:", fg="#FFFFFF", bg="#2A2D32").grid(row=4, column=0, sticky="w", pady=5)
        self.fraud_score_entry = tk.Entry(self.frame, width=10, bg="#3A3D42", fg="#FFFFFF", insertbackground="white")
        self.fraud_score_entry.grid(row=4, column=1, pady=5, sticky="w")
        self.fraud_score_entry.insert(0, self.settings.get("fraud_score", "15"))

        # Filter Residential IP
        self.filter_residential_var = tk.BooleanVar(value=self.settings.get("filter_residential", False))
        self.filter_residential_checkbox = tk.Checkbutton(self.frame, text="Filter Residential IP", variable=self.filter_residential_var, fg="#FFFFFF", bg="#2A2D32", selectcolor="#2A2D32")
        self.filter_residential_checkbox.grid(row=5, column=0, columnspan=2, sticky="w", pady=5)

        # ProxyCheck.io API Key
        tk.Label(self.frame, text="ProxyCheck.io API Key:", fg="#FFFFFF", bg="#2A2D32").grid(row=6, column=0, sticky="w", pady=5)
        self.api_key_entry = tk.Entry(self.frame, width=40, bg="#3A3D42", fg="#FFFFFF", insertbackground="white")
        self.api_key_entry.grid(row=6, column=1, columnspan=2, pady=5, sticky="w")
        self.api_key_entry.insert(0, self.settings.get("api_key", ""))

        # Residential IP Filter Types
        tk.Label(self.frame, text="Residential IP Filters:", fg="#FFFFFF", bg="#2A2D32").grid(row=7, column=0, sticky="w", pady=5)
        self.residential_var = tk.BooleanVar(value=self.settings.get("residential", False))
        self.wireless_var = tk.BooleanVar(value=self.settings.get("wireless", False))
        self.business_var = tk.BooleanVar(value=self.settings.get("business", False))

        self.residential_check = tk.Checkbutton(self.frame, text="Residential", variable=self.residential_var, fg="#FFFFFF", bg="#2A2D32", selectcolor="#2A2D32")
        self.residential_check.grid(row=8, column=0, sticky="w")
        self.wireless_check = tk.Checkbutton(self.frame, text="Wireless", variable=self.wireless_var, fg="#FFFFFF", bg="#2A2D32", selectcolor="#2A2D32")
        self.wireless_check.grid(row=8, column=1, sticky="w")
        self.business_check = tk.Checkbutton(self.frame, text="Business", variable=self.business_var, fg="#FFFFFF", bg="#2A2D32", selectcolor="#2A2D32")
        self.business_check.grid(row=8, column=2, sticky="w")

        # Save Button
        tk.Button(self.frame, text="Save Settings", command=self.load_proxies, bg="#4CAF50", fg="white", padx=10, pady=5).grid(row=9, column=0, columnspan=3, pady=10)

    def browse_file(self):
        """Open file dialog to select proxy file"""
        file_path = filedialog.askopenfilename(title="Select Proxy File", filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if file_path:
            self.proxy_file_entry.delete(0, tk.END)
            self.proxy_file_entry.insert(0, file_path)
            self.settings["proxy_file"] = file_path  # Save setting

    def load_proxies(self):
        """Save settings and validate input"""
        self.settings["proxy_quality"] = self.proxy_quality.get()
        self.settings["proxy_checking"] = self.proxy_checking.get()
        self.settings["fraud_score"] = self.fraud_score_entry.get()
        self.settings["filter_residential"] = self.filter_residential_var.get()
        self.settings["api_key"] = self.api_key_entry.get().strip()
        self.settings["residential"] = self.residential_var.get()
        self.settings["wireless"] = self.wireless_var.get()
        self.settings["business"] = self.business_var.get()

        # Validate fraud score
        try:
            fraud_score = int(self.settings["fraud_score"])
            if fraud_score < 0:
                raise ValueError("Fraud score cannot be negative.")
        except ValueError as e:
            messagebox.showerror("Invalid Input", f"Invalid fraud score: {e}")
            return

        # Save settings
        self.save_settings()

        # Display settings
        print("Proxy Settings Saved:")
        for key, value in self.settings.items():
            print(f"{key}: {value}")

        messagebox.showinfo("Success", "Proxy settings saved successfully.")

    def save_settings(self):
        """Save proxy settings to a JSON file."""
        with open(self.settings_file, "w") as f:
            json.dump(self.settings, f, indent=4)

    def load_settings(self):
        """Load proxy settings from a JSON file."""
        try:
            with open(self.settings_file, "r") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Proxy Setup")
    root.configure(bg="#2A2D32")
    app = ProxySetupUI(root)
    root.mainloop()
